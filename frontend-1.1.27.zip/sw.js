/* Generated at build time. Keep /sw.js and scope / to replace the previous Workbox worker. */
const CACHE_PREFIX = "juleoelkalender-precache-";
const CACHE_NAME = CACHE_PREFIX + "637f19c737a0225d7945";
const PRECACHE = ["/android-chrome-192x192.png","/android-chrome-512x512.png","/apple-touch-icon.png","/assets/Beers-UyKsZT36.js","/assets/CpuLoad-h3T6kkzm.js","/assets/DiskUsage-BB0dpnKr.js","/assets/FreeMemory-1e-_ZC40.js","/assets/H2-BfNg0bkG.js","/assets/HttpExchanges-D3BHisl9.js","/assets/InputCheckbox-BtCrHO3U.js","/assets/InputEmail-SUBJDRdY.js","/assets/InputField-Dl0YeRya.js","/assets/InputNumber-CGveRh23.js","/assets/InputPassword-CGqGzuqu.js","/assets/InputText-BUU9JnYY.js","/assets/ModalDialog-DiIG9_rS.js","/assets/MyBeersTable-E32RJCg4.js","/assets/MyCalendarsTable-DSM84p3_.js","/assets/Uptime-BfYP-f-x.js","/assets/UserForm-B34b6Vsx.js","/assets/Users-DlPWB5vC.js","/assets/Version-CXGCf8lU.js","/assets/ViewBeerModal-DnkdXe3j.js","/assets/addtoken.page-Bl5-EFv-.js","/assets/admin.dashboard.page-DYh3VoUd.js","/assets/authApi-ChJxadkB.js","/assets/auth~index-jyY0sU2d.js","/assets/auth~login.page-BqkAe_hR.js","/assets/beerApi-CLwK9b_2.js","/assets/beerCalendarApi-B_bh7lIN.js","/assets/beerStyleApi-BbbYxMxv.js","/assets/beers.page-1N2SHDOq.js","/assets/beerstyles.page-DyTBUXN9.js","/assets/calendar.edit.page-CBz38oPR.js","/assets/calendar.review.page-qJkM398t.js","/assets/calendarApi-CgekdqPH.js","/assets/calendarTokenApi-IFNHxbHz.js","/assets/calendarTokenSchema-BoMsmaKY.js","/assets/calendars.page-Ckv8n9kk.js","/assets/calendarview.page-CutXAxNh.js","/assets/coerce-M2IvOUJy.js","/assets/details.page-BRqIdHlE.js","/assets/edit.page-C8WTBIJ7.js","/assets/edit.user.page-Be5S78vo.js","/assets/environment-SpPOGrDR.js","/assets/forgottenpassword.page-OmGRCaG2.js","/assets/format-l0HLIr7o.js","/assets/home.page-CVdRvsTL.js","/assets/i18next~index-Dq_Jucma.js","/assets/i18next~index~addtoken.page~beers.page~beerstyles.page~calendar.edit.page~index.page~tokens~fwkybj3w-CzOa4B6_.js","/assets/index-6Ngh0FQk.js","/assets/index-DT6DsT3z.css","/assets/index.page-CCZ_S-_F.js","/assets/index.page-CZE2PMsu.js","/assets/index.page-CsoNq2eE.js","/assets/isAfter-DFmLBdqP.js","/assets/login.page-DfQQ9vm4.js","/assets/logout.page-DYvy-v4U.js","/assets/pagenotfound.page-DqYGU08r.js","/assets/parseISO-BIvyihTL.js","/assets/react~index-DZQRhZCn.js","/assets/react~index~addtoken.page~beers.page~beerstyles.page~calendar.edit.page~index.page~tokens.p~lgnr2u2m-JNKNqq_b.js","/assets/redux~index-CMV2M3-_.js","/assets/redux~index~addtoken.page~beers.page~beerstyles.page~calendar.edit.page~index.page~tokens.p~k0q9yos3-DN-UAiv-.js","/assets/redux~index~addtoken.page~beers.page~beerstyles.page~calendar.edit.page~index.page~tokens.p~k46uo2dw-BnJuvqG-.js","/assets/register.page-C-BjDB_m.js","/assets/review.page-DgoNmPyo.js","/assets/reviewApi-CT2lMZ0d.js","/assets/reviewWithoutChildrenSchema-SXFw-QZS.js","/assets/rolldown-runtime-XKyaHtl9.js","/assets/tableTypes-BrwFvbfZ.js","/assets/toDate-B3HYxwtT.js","/assets/tokens.page-Cl3k0CuA.js","/assets/total.reviews.page-BhP3Q5GV.js","/assets/unauthorize.page-CQxuwQ0D.js","/assets/user.page-BDYGMsUF.js","/assets/userApi-D1ZENd0Q.js","/assets/v4-DDdyfk2q.js","/assets/zod-CNGZs-w3.js","/assets/zod.gen-D7x_RmkR.js","/favicon-16x16.png","/favicon-32x32.png","/favicon.ico","/index.html","/manifest.webmanifest"];
// These public dictionaries are needed even when a lazy page is opened offline for the first time.
const LOCALES = ["/locales/no/translation.json", "/locales/en/translation.json"];
const ASSETS = new Set(PRECACHE);

self.addEventListener("install", (event) => {
  event.waitUntil(
    (async () => {
      const cache = await caches.open(CACHE_NAME);
      // Do not activate a partial release or reuse stale HTTP-cache responses.
      await cache.addAll([...new Set([...PRECACHE, ...LOCALES])].map((url) => new Request(url, { cache: "reload" })));
      await self.skipWaiting();
    })(),
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    (async () => {
      const names = await caches.keys();
      const obsolete = names.filter(
        (name) =>
          name !== CACHE_NAME &&
          (name.startsWith(CACHE_PREFIX) ||
            (name.startsWith("workbox-precache-") && name.endsWith(self.registration.scope))),
      );
      await Promise.all(obsolete.map((name) => caches.delete(name)));
      await self.clients.claim();
      // Old pages do not have our registration code. Navigate them from the worker
      // itself, both during Workbox migration and on subsequent automatic updates.
      if (obsolete.length) {
        const clients = await self.clients.matchAll({ type: "window" });
        await Promise.allSettled(clients.map((client) => client.navigate(client.url)));
      }
    })(),
  );
});

self.addEventListener("fetch", (event) => {
  const { request } = event;
  const url = new URL(request.url);
  if (request.method !== "GET" || url.origin !== self.location.origin) return;
  // Public translations use fresh responses online and the installed copy offline.
  if (LOCALES.includes(url.pathname)) {
    event.respondWith(
      (async () => {
        const cache = await caches.open(CACHE_NAME);
        try {
          const response = await fetch(request);
          if (response.ok) {
            await cache.put(url.pathname, response.clone());
            return response;
          }
          return (await cache.match(url.pathname)) ?? response;
        } catch (error) {
          const cached = await cache.match(url.pathname);
          if (cached) return cached;
          throw error;
        }
      })(),
    );
    return;
  }
  // API requests, authentication endpoints and private user data bypass this cache.
  // /login and /logout are client-side SPA routes; server authentication lives under /api or /oauth2.
  const navigation =
    request.mode === "navigate" && !/^\/(?:api|oauth2|locales|login\/oauth2)(?:\/|$)/.test(url.pathname);
  if (!navigation && !ASSETS.has(url.pathname)) return;
  event.respondWith(
    (async () => {
      const cache = await caches.open(CACHE_NAME);
      // Use the shell from the same release as the cached JS and CSS, including
      // deep links and offline reloads. Query strings do not change static assets.
      const cached = await cache.match(navigation ? "/index.html" : url.pathname);
      return cached ?? fetch(request);
    })(),
  );
});
