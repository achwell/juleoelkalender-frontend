/* Generated at build time. Keep /sw.js and scope / to replace the previous Workbox worker. */
const CACHE_PREFIX = "juleoelkalender-precache-";
const CACHE_NAME = CACHE_PREFIX + "ec9dab397a3cade196e7";
const PRECACHE = ["/android-chrome-192x192.png","/android-chrome-512x512.png","/apple-touch-icon.png","/assets/Beers-hxnCpAQ6.js","/assets/CpuLoad-CBh6N-Q3.js","/assets/DiskUsage-DU41oo9t.js","/assets/FreeMemory-Dc18BXas.js","/assets/H2-BfNg0bkG.js","/assets/HttpExchanges-DIdB14Uz.js","/assets/InputCheckbox-D5hjoMHb.js","/assets/InputEmail-DLesPgm-.js","/assets/InputField-DiAs7HC9.js","/assets/InputNumber-3llz5q9R.js","/assets/InputPassword-xKW6D65q.js","/assets/InputText-DBlotNEB.js","/assets/ModalDialog-DiIG9_rS.js","/assets/MyBeersTable-vQOb9Q5X.js","/assets/MyCalendarsTable-CDc21gFb.js","/assets/Uptime-BdVgGLbk.js","/assets/UserForm-BFWALM5I.js","/assets/Users-BC7MZs_c.js","/assets/Version-D8y9EzL1.js","/assets/ViewBeerModal-BBsDdTQo.js","/assets/addtoken.page-ytxyJ6Ss.js","/assets/admin.dashboard.page-CMg0EMJU.js","/assets/authApi-x5Ny6P2u.js","/assets/auth~index-jyY0sU2d.js","/assets/auth~login.page-BqkAe_hR.js","/assets/beerApi-BEZXY4hl.js","/assets/beerCalendarApi-a36Q63Jz.js","/assets/beerStyleApi-87blRdq1.js","/assets/beers.page-BulIs4Ek.js","/assets/beerstyles.page-BR7KPvUu.js","/assets/calendar.edit.page-DqWIhCJN.js","/assets/calendar.review.page-BpokRLOn.js","/assets/calendarApi-D5T5udm-.js","/assets/calendarTokenApi-C8uXFJAi.js","/assets/calendarTokenSchema-jXzxYEtx.js","/assets/calendars.page-CvUdDR9Y.js","/assets/calendarview.page-kvSk8EAy.js","/assets/coerce-DffMELSI.js","/assets/details.page-BTSzI7PS.js","/assets/edit.page-BPOP3Gkm.js","/assets/edit.user.page-BIceaO7j.js","/assets/environment-SpPOGrDR.js","/assets/forgottenpassword.page-CU4lladc.js","/assets/format-l0HLIr7o.js","/assets/home.page-XGNpf4EN.js","/assets/i18next~index-Dq_Jucma.js","/assets/i18next~index~addtoken.page~beers.page~beerstyles.page~calendar.edit.page~index.page~tokens~fwkybj3w-CzOa4B6_.js","/assets/index-CrWL4arA.js","/assets/index-DT6DsT3z.css","/assets/index.page-DSMZK51c.js","/assets/index.page-DY45b-WR.js","/assets/index.page-DrgdHxVY.js","/assets/isAfter-DFmLBdqP.js","/assets/login.page-B1k1f43v.js","/assets/logout.page-CXxiy7pV.js","/assets/pagenotfound.page-BDM8UAd7.js","/assets/parseISO-BIvyihTL.js","/assets/react~index-DZQRhZCn.js","/assets/react~index~addtoken.page~beers.page~beerstyles.page~calendar.edit.page~index.page~tokens.p~lgnr2u2m-JNKNqq_b.js","/assets/redux~index-CMV2M3-_.js","/assets/redux~index~addtoken.page~beers.page~beerstyles.page~calendar.edit.page~index.page~tokens.p~k0q9yos3-DN-UAiv-.js","/assets/redux~index~addtoken.page~beers.page~beerstyles.page~calendar.edit.page~index.page~tokens.p~k46uo2dw-BnJuvqG-.js","/assets/register.page-xnz4NmrB.js","/assets/review.page-_k1wIeKW.js","/assets/reviewApi-DH9KQNbZ.js","/assets/reviewWithoutChildrenSchema-H7knn5e3.js","/assets/rolldown-runtime-XKyaHtl9.js","/assets/tableTypes-3d9T5ZLJ.js","/assets/toDate-B3HYxwtT.js","/assets/tokens.page-DUDLPby6.js","/assets/total.reviews.page-BA9VPLSg.js","/assets/unauthorize.page-DqeEsegu.js","/assets/user.page-1vp9ifBW.js","/assets/userApi-C5XCWEbp.js","/assets/v4-DDdyfk2q.js","/assets/zod-Ct-sA9-q.js","/assets/zod.gen-DT3g6XeS.js","/favicon-16x16.png","/favicon-32x32.png","/favicon.ico","/index.html","/manifest.webmanifest"];
// These public dictionaries are needed even when a lazy page is opened offline for the first time.
const LOCALES = ["/locales/no/translation.json", "/locales/en/translation.json"];
const ASSETS = new Set(PRECACHE);

self.addEventListener("install", (event) => {
  event.waitUntil(
    (async () => {
      const cache = await caches.open(CACHE_NAME);
      // Do not activate a partial release or reuse stale HTTP-cache responses.
      await cache.addAll([...new Set([...PRECACHE, ...LOCALES])].map((url) => new Request(url, { cache: "reload" })));
      await self.skipWaiting();
    })(),
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    (async () => {
      const names = await caches.keys();
      const obsolete = names.filter(
        (name) =>
          name !== CACHE_NAME &&
          (name.startsWith(CACHE_PREFIX) ||
            (name.startsWith("workbox-precache-") && name.endsWith(self.registration.scope))),
      );
      await Promise.all(obsolete.map((name) => caches.delete(name)));
      await self.clients.claim();
      // Old pages do not have our registration code. Navigate them from the worker
      // itself, both during Workbox migration and on subsequent automatic updates.
      if (obsolete.length) {
        const clients = await self.clients.matchAll({ type: "window" });
        await Promise.allSettled(clients.map((client) => client.navigate(client.url)));
      }
    })(),
  );
});

self.addEventListener("fetch", (event) => {
  const { request } = event;
  const url = new URL(request.url);
  if (request.method !== "GET" || url.origin !== self.location.origin) return;
  // Public translations use fresh responses online and the installed copy offline.
  if (LOCALES.includes(url.pathname)) {
    event.respondWith(
      (async () => {
        const cache = await caches.open(CACHE_NAME);
        try {
          const response = await fetch(request);
          if (response.ok) {
            await cache.put(url.pathname, response.clone());
            return response;
          }
          return (await cache.match(url.pathname)) ?? response;
        } catch (error) {
          const cached = await cache.match(url.pathname);
          if (cached) return cached;
          throw error;
        }
      })(),
    );
    return;
  }
  // API requests, authentication endpoints and private user data bypass this cache.
  // /login and /logout are client-side SPA routes; server authentication lives under /api or /oauth2.
  const navigation =
    request.mode === "navigate" && !/^\/(?:api|oauth2|locales|login\/oauth2)(?:\/|$)/.test(url.pathname);
  if (!navigation && !ASSETS.has(url.pathname)) return;
  event.respondWith(
    (async () => {
      const cache = await caches.open(CACHE_NAME);
      // Use the shell from the same release as the cached JS and CSS, including
      // deep links and offline reloads. Query strings do not change static assets.
      const cached = await cache.match(navigation ? "/index.html" : url.pathname);
      return cached ?? fetch(request);
    })(),
  );
});
