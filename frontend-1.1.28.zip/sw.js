/* Generated at build time. Keep /sw.js and scope / to replace the previous Workbox worker. */
const CACHE_PREFIX = "juleoelkalender-precache-";
const CACHE_NAME = CACHE_PREFIX + "44967b441d5d9a813d93";
const PRECACHE = ["/android-chrome-192x192.png","/android-chrome-512x512.png","/apple-touch-icon.png","/assets/Beers-CShX9lJQ.js","/assets/CpuLoad-UmFe4ex8.js","/assets/DiskUsage-MCgrfVaj.js","/assets/FreeMemory-B3AeYnTC.js","/assets/H2-BfNg0bkG.js","/assets/HttpExchanges-D9YFRJIH.js","/assets/InputCheckbox-DxASQyq-.js","/assets/InputEmail-BVoZO4Og.js","/assets/InputField-DSNWmDVn.js","/assets/InputNumber-B2Nubomp.js","/assets/InputPassword-CL5bGwzf.js","/assets/InputText-CCKpfiR1.js","/assets/ModalDialog-DiIG9_rS.js","/assets/MyBeersTable-BC9pYQV-.js","/assets/MyCalendarsTable-JZMS6my8.js","/assets/Uptime-BXc-fFxZ.js","/assets/UserForm-uSVpuIkP.js","/assets/Users-DBC8fg2A.js","/assets/Version-D6OH4-9U.js","/assets/ViewBeerModal-BGd1TjY9.js","/assets/addtoken.page-B4fn5Bnl.js","/assets/admin.dashboard.page-Czq1_f2K.js","/assets/authApi-DmQmf3Hs.js","/assets/auth~index-jyY0sU2d.js","/assets/auth~login.page-BqkAe_hR.js","/assets/beerApi-BzDN0jiq.js","/assets/beerCalendarApi-Gkt6fH0z.js","/assets/beerStyleApi-DQ63Fj0d.js","/assets/beers.page-0vpYoFL2.js","/assets/beerstyles.page-BefmvMzg.js","/assets/calendar.edit.page-C0eO5EYd.js","/assets/calendar.review.page-C5eGLb7_.js","/assets/calendarApi-CLc3LpK_.js","/assets/calendarTokenApi-C51VB2lN.js","/assets/calendarTokenSchema-BKLHX4EM.js","/assets/calendars.page-CCZiqq6-.js","/assets/calendarview.page-BwtyxTbj.js","/assets/coerce-DUzhjNf0.js","/assets/details.page-B_004SnO.js","/assets/edit.page-BdhYfCAo.js","/assets/edit.user.page-XGRsQYWa.js","/assets/environment-SpPOGrDR.js","/assets/forgottenpassword.page-CMj_9fGU.js","/assets/format-l0HLIr7o.js","/assets/home.page-D7bBo59O.js","/assets/i18next~index-Dq_Jucma.js","/assets/i18next~index~addtoken.page~beers.page~beerstyles.page~calendar.edit.page~index.page~tokens~fwkybj3w-CzOa4B6_.js","/assets/index-B8Kkd-ZB.js","/assets/index-DT6DsT3z.css","/assets/index.page-BhYRFly5.js","/assets/index.page-CpwkkypD.js","/assets/index.page-DcfiAC3H.js","/assets/isAfter-DFmLBdqP.js","/assets/login.page-DqE8Uy17.js","/assets/logout.page-xv12qElp.js","/assets/pagenotfound.page-Bx3zf7xJ.js","/assets/parseISO-BIvyihTL.js","/assets/react~index-DZQRhZCn.js","/assets/react~index~addtoken.page~beers.page~beerstyles.page~calendar.edit.page~index.page~tokens.p~lgnr2u2m-JNKNqq_b.js","/assets/redux~index-CMV2M3-_.js","/assets/redux~index~addtoken.page~beers.page~beerstyles.page~calendar.edit.page~index.page~tokens.p~k0q9yos3-DN-UAiv-.js","/assets/redux~index~addtoken.page~beers.page~beerstyles.page~calendar.edit.page~index.page~tokens.p~k46uo2dw-BnJuvqG-.js","/assets/register.page-kypYGFyw.js","/assets/review.page-D5NUTMkZ.js","/assets/reviewApi-CR_bVuYh.js","/assets/reviewWithoutChildrenSchema-DD0SF6_S.js","/assets/rolldown-runtime-XKyaHtl9.js","/assets/tableTypes-1lKUCDPm.js","/assets/toDate-B3HYxwtT.js","/assets/tokens.page-BKs0uSuP.js","/assets/total.reviews.page-D-7rWXhZ.js","/assets/unauthorize.page-BAjPu09k.js","/assets/user.page-LA7tBL0l.js","/assets/userApi-D8Kc0HaX.js","/assets/v4-DDdyfk2q.js","/assets/zod-BbbV8MJO.js","/assets/zod.gen-CEmRhtr8.js","/favicon-16x16.png","/favicon-32x32.png","/favicon.ico","/index.html","/manifest.webmanifest"];
// These public dictionaries are needed even when a lazy page is opened offline for the first time.
const LOCALES = ["/locales/no/translation.json", "/locales/en/translation.json"];
const ASSETS = new Set(PRECACHE);

self.addEventListener("install", (event) => {
  event.waitUntil(
    (async () => {
      const cache = await caches.open(CACHE_NAME);
      // Do not activate a partial release or reuse stale HTTP-cache responses.
      await cache.addAll([...new Set([...PRECACHE, ...LOCALES])].map((url) => new Request(url, { cache: "reload" })));
      await self.skipWaiting();
    })(),
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    (async () => {
      const names = await caches.keys();
      const obsolete = names.filter(
        (name) =>
          name !== CACHE_NAME &&
          (name.startsWith(CACHE_PREFIX) ||
            (name.startsWith("workbox-precache-") && name.endsWith(self.registration.scope))),
      );
      await Promise.all(obsolete.map((name) => caches.delete(name)));
      await self.clients.claim();
      // Old pages do not have our registration code. Navigate them from the worker
      // itself, both during Workbox migration and on subsequent automatic updates.
      if (obsolete.length) {
        const clients = await self.clients.matchAll({ type: "window" });
        await Promise.allSettled(clients.map((client) => client.navigate(client.url)));
      }
    })(),
  );
});

self.addEventListener("fetch", (event) => {
  const { request } = event;
  const url = new URL(request.url);
  if (request.method !== "GET" || url.origin !== self.location.origin) return;
  // Public translations use fresh responses online and the installed copy offline.
  if (LOCALES.includes(url.pathname)) {
    event.respondWith(
      (async () => {
        const cache = await caches.open(CACHE_NAME);
        try {
          const response = await fetch(request);
          if (response.ok) {
            await cache.put(url.pathname, response.clone());
            return response;
          }
          return (await cache.match(url.pathname)) ?? response;
        } catch (error) {
          const cached = await cache.match(url.pathname);
          if (cached) return cached;
          throw error;
        }
      })(),
    );
    return;
  }
  // API requests, authentication endpoints and private user data bypass this cache.
  // /login and /logout are client-side SPA routes; server authentication lives under /api or /oauth2.
  const navigation =
    request.mode === "navigate" && !/^\/(?:api|oauth2|locales|login\/oauth2)(?:\/|$)/.test(url.pathname);
  if (!navigation && !ASSETS.has(url.pathname)) return;
  event.respondWith(
    (async () => {
      const cache = await caches.open(CACHE_NAME);
      // Use the shell from the same release as the cached JS and CSS, including
      // deep links and offline reloads. Query strings do not change static assets.
      const cached = await cache.match(navigation ? "/index.html" : url.pathname);
      return cached ?? fetch(request);
    })(),
  );
});
