/* Generated at build time. Keep /sw.js and scope / to replace the previous Workbox worker. */
const CACHE_PREFIX = "juleoelkalender-precache-";
const CACHE_NAME = CACHE_PREFIX + "b1de6732112632456b0c";
const PRECACHE = ["/android-chrome-192x192.png","/android-chrome-512x512.png","/apple-touch-icon.png","/assets/Beers-CNvfMv2I.js","/assets/CpuLoad-lbwImSZo.js","/assets/DiskUsage-mjeYXvDc.js","/assets/FreeMemory-wJ7PKjtX.js","/assets/H2-C73ypAuZ.js","/assets/HttpExchanges-C9l3eTj5.js","/assets/InputCheckbox-ccI_fPU4.js","/assets/InputEmail-Dytb7ztf.js","/assets/InputField-COmV4wnu.js","/assets/InputNumber-B7jPZ2tT.js","/assets/InputPassword-QC4jESUK.js","/assets/InputText-BOK4whbJ.js","/assets/InputTextArea-CK97kjYC.js","/assets/ModalDialog-9RRsXMd5.js","/assets/MyBeersTable-9A3sqAm1.js","/assets/MyCalendarsTable-DGsI_uDK.js","/assets/Uptime-PQ54PiRv.js","/assets/UserForm-DqVyjPLZ.js","/assets/Users-BMeDdfZc.js","/assets/Version-he6oWqHh.js","/assets/ViewBeerModal-D7ftPPuT.js","/assets/addtoken.page-RXqyUEiz.js","/assets/admin.dashboard.page-DqNcPh7r.js","/assets/authApi-C8XnwRT-.js","/assets/auth~index-jyY0sU2d.js","/assets/auth~login.page-BqkAe_hR.js","/assets/beerApi-D0pEbpEa.js","/assets/beerCalendarApi-9vLD7j67.js","/assets/beerStyleApi-Biuh_KIf.js","/assets/beers.page-DWVNmRuM.js","/assets/beerstyles.page-BR5DdOUy.js","/assets/calendar.edit.page-Bxg241rH.js","/assets/calendar.review.page-Cgg9xFhb.js","/assets/calendarApi-DPHGBYXU.js","/assets/calendarTokenApi-_fU8pYQD.js","/assets/calendarTokenSchema-BA31vPBN.js","/assets/calendars.page-BHDkOyPK.js","/assets/calendarview.page-BpYg2Mcx.js","/assets/coerce-rDQ4Bbod.js","/assets/details.page-D3Jjs3B7.js","/assets/edit.page-DwICjaEz.js","/assets/edit.user.page-C9GfTxgZ.js","/assets/environment-SpPOGrDR.js","/assets/forgottenpassword.page-C61WK848.js","/assets/format-l0HLIr7o.js","/assets/home.page-DYXL3Thn.js","/assets/i18next~index-Cc2x90O_.js","/assets/i18next~index~addtoken.page~beers.page~beerstyles.page~calendar.edit.page~index.page~tokens~fwkybj3w-CLGSnn4B.js","/assets/index-BkYZovdY.css","/assets/index-C99FWW0l.js","/assets/index.page-B76xo0H5.js","/assets/index.page-CnLLi0v-.js","/assets/index.page-DcR70LXJ.js","/assets/isAfter-DFmLBdqP.js","/assets/login.page-litKJ8V_.js","/assets/logout.page-FDZpqjhz.js","/assets/pagenotfound.page-DDmG3giG.js","/assets/parseISO-BIvyihTL.js","/assets/react~index-DZQRhZCn.js","/assets/react~index~addtoken.page~beers.page~beerstyles.page~calendar.edit.page~index.page~tokens.p~lgnr2u2m-JNKNqq_b.js","/assets/redux~index-BTC3t_5z.js","/assets/redux~index~addtoken.page~beers.page~beerstyles.page~calendar.edit.page~index.page~tokens.p~k0q9yos3-DN-UAiv-.js","/assets/redux~index~addtoken.page~beers.page~beerstyles.page~calendar.edit.page~index.page~tokens.p~k46uo2dw-BnJuvqG-.js","/assets/register.page-DRmHfJ7C.js","/assets/review.page-BQ85XcRY.js","/assets/reviewApi-DoU4ZOzB.js","/assets/rolldown-runtime-XKyaHtl9.js","/assets/tableTypes-ya3Wqzbs.js","/assets/toDate-B3HYxwtT.js","/assets/tokens.page-BZDyy6dl.js","/assets/total.reviews.page-CZppcGH7.js","/assets/unauthorize.page-C3qQVo-e.js","/assets/user.page-B8DkTaxA.js","/assets/userApi-DvElZ0LM.js","/assets/v4-DDdyfk2q.js","/assets/zod-WPXKJUnm.js","/assets/zod.gen-CbkzIxA-.js","/favicon-16x16.png","/favicon-32x32.png","/favicon.ico","/index.html","/manifest.webmanifest"];
// These public dictionaries are needed even when a lazy page is opened offline for the first time.
const LOCALES = ["/locales/no/translation.json", "/locales/en/translation.json"];
const ASSETS = new Set(PRECACHE);

self.addEventListener("install", (event) => {
  event.waitUntil(
    (async () => {
      const cache = await caches.open(CACHE_NAME);
      // Do not activate a partial release or reuse stale HTTP-cache responses.
      await cache.addAll([...new Set([...PRECACHE, ...LOCALES])].map((url) => new Request(url, { cache: "reload" })));
      await self.skipWaiting();
    })(),
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    (async () => {
      const names = await caches.keys();
      const obsolete = names.filter(
        (name) =>
          name !== CACHE_NAME &&
          (name.startsWith(CACHE_PREFIX) ||
            (name.startsWith("workbox-precache-") && name.endsWith(self.registration.scope))),
      );
      await Promise.all(obsolete.map((name) => caches.delete(name)));
      await self.clients.claim();
      // Old pages do not have our registration code. Navigate them from the worker
      // itself, both during Workbox migration and on subsequent automatic updates.
      if (obsolete.length) {
        const clients = await self.clients.matchAll({ type: "window" });
        await Promise.allSettled(clients.map((client) => client.navigate(client.url)));
      }
    })(),
  );
});

self.addEventListener("fetch", (event) => {
  const { request } = event;
  const url = new URL(request.url);
  if (request.method !== "GET" || url.origin !== self.location.origin) return;
  // Public translations use fresh responses online and the installed copy offline.
  if (LOCALES.includes(url.pathname)) {
    event.respondWith(
      (async () => {
        const cache = await caches.open(CACHE_NAME);
        try {
          const response = await fetch(request);
          if (response.ok) {
            await cache.put(url.pathname, response.clone());
            return response;
          }
          return (await cache.match(url.pathname)) ?? response;
        } catch (error) {
          const cached = await cache.match(url.pathname);
          if (cached) return cached;
          throw error;
        }
      })(),
    );
    return;
  }
  // API requests, authentication endpoints and private user data bypass this cache.
  // /login and /logout are client-side SPA routes; server authentication lives under /api or /oauth2.
  const navigation =
    request.mode === "navigate" && !/^\/(?:api|oauth2|locales|login\/oauth2)(?:\/|$)/.test(url.pathname);
  if (!navigation && !ASSETS.has(url.pathname)) return;
  event.respondWith(
    (async () => {
      const cache = await caches.open(CACHE_NAME);
      // Use the shell from the same release as the cached JS and CSS, including
      // deep links and offline reloads. Query strings do not change static assets.
      const cached = await cache.match(navigation ? "/index.html" : url.pathname);
      return cached ?? fetch(request);
    })(),
  );
});
